/**
 * CartOCR Scraper - Content Script
 * 핫링크 회피, CORS 우회 및 상품 이미지 저장소 Whitelist 매칭 로직이 탑재된 최종 V6 스크래퍼
 */

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "scrape_cart") {
        scrapeCurrentCart()
            .then(result => {
                sendResponse({ success: true, items: result });
            })
            .catch(error => {
                console.error("CartOCR 파싱 중 오류:", error);
                sendResponse({ success: false, error: error.message });
            });
    }
    return true; // 비동기 응답 필수
});

async function scrapeCurrentCart() {
    let items = [];
    const debugLog = [];

    // 1단계: 쇼핑몰 솔루션별 맞춤형 하드코딩 파서 우선 작동 (고도몰, Cafe24 등)
    try {
        items = await parseKnownMallCart(debugLog);
        if (items && items.length > 0) {
            console.log("1단계 맞춤형 파서 성공:", items);
            return items;
        }
    } catch (e) {
        debugLog.push(`1단계 실패: ${e.message}`);
    }

    // 2단계: 스마트 범용 테이블 파서 작동
    try {
        items = await parseGenericTableCart(debugLog);
        if (items && items.length > 0) {
            console.log("2단계 범용 테이블 파서 성공:", items);
            return items;
        }
    } catch (e) {
        debugLog.push(`2단계 실패: ${e.message}`);
    }

    // 3단계: Div 기반 스크래퍼 작동 (테이블이 없을 때)
    try {
        items = await parseDivBasedCart(debugLog);
        if (items && items.length > 0) {
            console.log("3단계 Div 기반 파서 성공:", items);
            return items;
        }
    } catch (e) {
        debugLog.push(`3단계 실패: ${e.message}`);
    }

    // 4단계: 무차별 텍스트 매칭 파서 (Brute Force Parser) - 최후의 수단
    try {
        items = await parseBruteForceCart(debugLog);
        if (items && items.length > 0) {
            console.log("4단계 최후의 무차별 파서 성공:", items);
            return items;
        }
    } catch (e) {
        debugLog.push(`4단계 실패: ${e.message}`);
    }

    const totalTables = document.querySelectorAll('table').length;
    const totalDivs = document.querySelectorAll('div').length;
    const errMsg = `장바구니 품목을 찾지 못했습니다.\n[시스템 진단]: 테이블 ${totalTables}개 / 디브 ${totalDivs}개 감지.\n[실패 로그]: ${debugLog.join(' -> ')}`;
    throw new Error(errMsg);
}

/**
 * 이미지 엘리먼트의 모든 속성을 스캔하여 진짜 상품 이미지 경로를 찾아내는 무차별 색출 함수 (Whitelist 기반 정밀 타격)
 */
function resolveImageUrl(imgEl) {
    if (!imgEl) return "";
    
    const attrs = imgEl.attributes;
    let rawSrc = "";
    
    // 이미지 내 모든 HTML 속성들을 스캔
    for (let i = 0; i < attrs.length; i++) {
        const attrName = attrs[i].name;
        const attrVal = attrs[i].value.trim();
        
        // base64 더미 인코딩 이미지 배제
        if (attrVal.startsWith("data:image")) continue;
        
        // [핵심 필터]: 실제 쇼핑몰의 '상품 이미지 저장 경로' 형식을 가진 주소만 통과시킵니다.
        // 이로써 체크박스, 삭제버튼, 닫기아이콘 등은 무조건 걸러집니다.
        const isProductImagePath = attrVal.includes("/goods/") || 
                                   attrVal.includes("/prod/") || 
                                   attrVal.includes("/product/") || 
                                   attrVal.includes("/shop/data/") ||
                                   attrVal.includes("/goods_img/") ||
                                   attrVal.includes("/item/");
                                   
        if (isProductImagePath) {
            if (attrName === "src") {
                if (!rawSrc) rawSrc = attrVal;
            } else {
                rawSrc = attrVal;
                break; // LazyLoad 전용 속성 우선 매칭
            }
        }
    }
    
    // 루프를 돌고도 못 찾았다면 최종 수단으로 브라우저가 평가한 imgEl.src 사용 (Whitelist 체크)
    if (!rawSrc) {
        const fallbackSrc = imgEl.src;
        if (
            fallbackSrc.includes("/goods/") || 
            fallbackSrc.includes("/prod/") || 
            fallbackSrc.includes("/product/") || 
            fallbackSrc.includes("/shop/data/") ||
            fallbackSrc.includes("/goods_img/") ||
            fallbackSrc.includes("/item/")
        ) {
            rawSrc = fallbackSrc;
        }
    }
    
    if (!rawSrc || rawSrc.startsWith("data:image")) return "";
    
    try {
        // 상대 경로를 도메인이 합쳐진 절대 경로로 온전히 변환
        return new URL(rawSrc, window.location.href).href;
    } catch (e) {
        let cleanSrc = rawSrc;
        if (cleanSrc.startsWith("//")) {
            cleanSrc = "https:" + cleanSrc;
        }
        return cleanSrc;
    }
}

/**
 * 이미지 URL을 백그라운드 서비스 워커(CORS 무시 정책)에 요청하여 Base64로 안전하게 변환해 오는 비동기 함수
 */
async function convertImageToBase64(imgUrl) {
    if (!imgUrl) return "";
    return new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: "fetch_image", url: imgUrl }, (response) => {
            if (chrome.runtime.lastError) {
                console.warn("백그라운드 통신 오류:", chrome.runtime.lastError.message);
                resolve("");
                return;
            }
            if (response && response.success) {
                resolve(response.data);
            } else {
                resolve("");
            }
        });
    });
}

/**
 * 1. 한국 주요 쇼핑몰 솔루션(고도몰, Cafe24 등) 규격 맞춤 파서
 */
async function parseKnownMallCart(debugLog) {
    const items = [];
    const url = window.location.href;

    if (url.includes("devicemart.co.kr")) {
        const rows = document.querySelectorAll("table tr, .order_table_type tbody tr, #cart_table tbody tr, .tbl_cart_list tbody tr");
        if (rows.length === 0) throw new Error("행 후보 없음");
        
        for (const row of rows) {
            const nameEl = row.querySelector("a[href*='goods_view'], td.subject a, .goods_name a, .prod_name, a[href*='goods/view']");
            if (!nameEl) continue;

            let name = nameEl.textContent.replace(/[\n\t]/g, "").trim();
            if (name.includes("삭제") || name.includes("변경") || name.length < 2) continue;

            const qtyInput = row.querySelector("input[name*='goodsCnt'], input[name*='qty'], input[id*='cnt'], .qty_input, input[name*='amount']");
            let quantity = 1;
            if (qtyInput) {
                quantity = parseInt(qtyInput.value, 10) || 1;
            } else {
                const qtyCell = row.querySelector("td:nth-child(4), td:nth-child(3)");
                if (qtyCell) quantity = parseInt(qtyCell.textContent.replace(/[^0-9]/g, ""), 10) || 1;
            }

            const priceEl = row.querySelector(".goods_price, .price, td.price, span.price_value, strong.price, td.price_cell");
            let price = 0;
            if (priceEl) {
                price = parseInt(priceEl.textContent.replace(/[^0-9]/g, ""), 10) || 0;
            }

            // 첫 번째 td(보통 체크박스)는 건너뛰고 이미지 찾기
            const cells = row.querySelectorAll("td");
            let imgEl = null;
            for (let i = 1; i < cells.length; i++) {
                imgEl = cells[i].querySelector("img");
                if (imgEl) {
                    const temp = resolveImageUrl(imgEl);
                    if (temp) {
                        break; // 유효한 상품 이미지 획득 시 중단
                    } else {
                        imgEl = null;
                    }
                }
            }
            if (!imgEl) {
                imgEl = row.querySelector("img");
            }
            
            const imageUrl = resolveImageUrl(imgEl);
            const image = await convertImageToBase64(imageUrl);

            const amount = price * quantity;
            if (name && price > 0) {
                items.push({ name, price, quantity, amount, image });
            }
        }
    } else if (url.includes("coupang.com")) {
        const dealRows = document.querySelectorAll(".cart-deal-item");
        for (const row of dealRows) {
            const nameEl = row.querySelector(".product-name, .item-title");
            if (!nameEl) continue;
            const name = nameEl.textContent.replace(/[\n\t]/g, "").trim();

            const qtyInput = row.querySelector(".quantity-select, .quantity-input, input[name='quantity']");
            let quantity = qtyInput ? (parseInt(qtyInput.value, 10) || 1) : 1;

            const priceEl = row.querySelector(".unit-price, .discount-price, .price-area .price");
            let price = priceEl ? (parseInt(priceEl.textContent.replace(/[^0-9]/g, ""), 10) || 0) : 0;

            const imgEl = row.querySelector("img.product-img, .cart-deal-item__img img");
            const imageUrl = resolveImageUrl(imgEl);
            const image = await convertImageToBase64(imageUrl);

            const amount = price * quantity;
            items.push({ name, price, quantity, amount, image });
        }
    }

    return items;
}

/**
 * 2. 범용 테이블 파서
 */
async function parseGenericTableCart(debugLog) {
    const tables = document.querySelectorAll("table");
    if (tables.length === 0) throw new Error("테이블 없음");
    
    let targetTable = null;
    let nameIdx = -1, qtyIdx = -1, priceIdx = -1, imgIdx = -1;

    for (const table of tables) {
        const headers = table.querySelectorAll("th, td");
        let hasProductHeader = false;
        let hasQtyHeader = false;
        let hasPriceHeader = false;

        headers.forEach((header, idx) => {
            const text = header.textContent.replace(/\s+/g, "").trim();
            if (/상품|품명|품목|subject|product|item/i.test(text)) hasProductHeader = true;
            if (/수량|qty|quantity|ea/i.test(text) && !/금액|합계/i.test(text)) hasQtyHeader = true;
            if (/단가|가격|상품금액|판매가|금액|price|unitprice/i.test(text)) hasPriceHeader = true;
        });

        if (hasProductHeader && (hasQtyHeader || hasPriceHeader)) {
            targetTable = table;
            break;
        }
    }

    if (!targetTable) {
        targetTable = tables[0];
    }

    const headerRow = targetTable.querySelector("thead tr, tr:first-child");
    if (!headerRow) throw new Error("테이블 헤더 없음");
    
    const headerCells = headerRow.querySelectorAll("th, td");
    headerCells.forEach((cell, idx) => {
        const text = cell.textContent.replace(/\s+/g, "").trim();
        if (/상품|품명|품목|명칭|subject|product|item/i.test(text) && nameIdx === -1) nameIdx = idx;
        if (/수량|qty|quantity|ea/i.test(text) && !/금액|합계/i.test(text) && qtyIdx === -1) qtyIdx = idx;
        if (/단가|가격|상품금액|판매가|price/i.test(text) && priceIdx === -1) priceIdx = idx;
        if (priceIdx === -1 && /금액|합계|amount|total/i.test(text)) priceIdx = idx;
        if (/이미지|사진|image|thumb/i.test(text) && imgIdx === -1) imgIdx = idx;
    });

    if (nameIdx === -1) nameIdx = 1;
    if (qtyIdx === -1) qtyIdx = 2;
    if (priceIdx === -1) priceIdx = 3;

    const items = [];
    const rows = targetTable.querySelectorAll("tbody tr, tr");
    
    for (const row of rows) {
        if (row === headerRow || row.querySelector("th") || row.classList.contains("total-row") || row.classList.contains("sum-row")) {
            continue;
        }

        const cells = row.querySelectorAll("td");
        if (cells.length <= Math.max(nameIdx, qtyIdx, priceIdx)) continue;

        try {
            const nameCell = cells[nameIdx];
            const nameLink = nameCell.querySelector("a, span, p");
            let name = nameLink ? nameLink.textContent : nameCell.textContent;
            name = name.replace(/[\n\t\r]/g, "").replace(/\s+/g, " ").trim();
            if (name.includes("삭제") || name.includes("변경") || name.length < 2) continue;

            const qtyCell = cells[qtyIdx];
            const qtyInput = qtyCell.querySelector("input, select");
            let quantity = qtyInput ? (parseInt(qtyInput.value, 10) || 1) : (parseInt(qtyCell.textContent.replace(/[^0-9]/g, ""), 10) || 1);

            const priceCell = cells[priceIdx];
            let price = parseInt(priceCell.textContent.replace(/[^0-9]/g, ""), 10) || 0;

            let imgEl = null;
            if (imgIdx !== -1 && cells[imgIdx]) {
                imgEl = cells[imgIdx].querySelector("img");
            }
            if (!imgEl) {
                // 첫번째 td(체크박스)를 피해 이미지 검색
                for (let i = 1; i < cells.length; i++) {
                    imgEl = cells[i].querySelector("img");
                    if (imgEl) {
                        const temp = resolveImageUrl(imgEl);
                        if (temp) break;
                        else imgEl = null;
                    }
                }
            }
            const imageUrl = resolveImageUrl(imgEl);
            const image = await convertImageToBase64(imageUrl);

            const amount = price * quantity;
            if (name && price > 0) {
                items.push({ name, price, quantity, amount, image });
            }
        } catch (err) {}
    }

    return items;
}

/**
 * 3. Div 기반 스크래퍼
 */
async function parseDivBasedCart(debugLog) {
    const items = [];
    const cartItemContainers = document.querySelectorAll("[class*='cart-item'], [class*='cart_item'], [class*='goods-item'], [class*='order-item']");
    if (cartItemContainers.length === 0) throw new Error("Div 컨테이너 없음");

    for (const container of cartItemContainers) {
        try {
            const nameEl = container.querySelector("[class*='name'], [class*='title'], a");
            if (!nameEl) continue;
            const name = nameEl.textContent.replace(/[\n\t]/g, "").trim();
            if (name.length < 2 || name.includes("삭제") || name.includes("변경")) continue;

            const qtyInput = container.querySelector("input[type='text'], input[type='number'], [class*='qty'], [class*='count']");
            let quantity = 1;
            if (qtyInput) {
                quantity = parseInt(qtyInput.value, 10) || parseInt(qtyInput.textContent.replace(/[^0-9]/g, ""), 10) || 1;
            }

            const priceEl = container.querySelector("[class*='price'], [class*='amount']");
            let price = priceEl ? (parseInt(priceEl.textContent.replace(/[^0-9]/g, ""), 10) || 0) : 0;

            const imgEl = container.querySelector("img");
            const imageUrl = resolveImageUrl(imgEl);
            const image = await convertImageToBase64(imageUrl);

            const amount = price * quantity;
            if (name && price > 0) {
                items.push({ name, price, quantity, amount, image });
            }
        } catch (e) {}
    }

    return items;
}

/**
 * 4. 무차별 텍스트 매칭 파서 (Brute Force Parser) - 최후의 카드
 */
async function parseBruteForceCart(debugLog) {
    const items = [];
    const inputs = document.querySelectorAll("input[type='text'], input[type='number'], input[name*='qty'], input[name*='cnt'], input[name*='amount']");

    for (const input of inputs) {
        try {
            const val = parseInt(input.value, 10);
            if (isNaN(val) || val <= 0 || val > 1000) continue;

            let wrapper = input.closest("tr, li, [class*='item'], [class*='list']");
            if (!wrapper) continue;

            const links = wrapper.querySelectorAll("a");
            let bestName = "";
            links.forEach(link => {
                const txt = link.textContent.replace(/[\n\t]/g, "").trim();
                if (txt.length > bestName.length && !txt.includes("삭제") && !txt.includes("변경") && !txt.includes("수정")) {
                    bestName = txt;
                }
            });

            if (!bestName) {
                const nameNode = wrapper.querySelector("[class*='name'], [class*='title']");
                if (nameNode) bestName = nameNode.textContent.replace(/[\n\t]/g, "").trim();
            }

            if (!bestName || bestName.length < 2) continue;
            if (items.some(item => item.name === bestName)) continue;

            const textNodes = [];
            const walk = document.createTreeWalker(wrapper, NodeFilter.SHOW_TEXT, null, false);
            let node;
            while(node = walk.nextNode()) {
                textNodes.push(node.textContent.trim());
            }

            let bestPrice = 0;
            for (const txt of textNodes) {
                const cleanTxt = txt.replace(/,/g, "");
                const match = cleanTxt.match(/([0-9]{3,8})\s*(?:원|₩|원화)?/);
                if (match) {
                    const priceVal = parseInt(match[1], 10);
                    if (priceVal >= 100 && (bestPrice === 0 || priceVal < bestPrice)) {
                        bestPrice = priceVal;
                    }
                }
            }

            // 래퍼 내에서 첫 번째 td가 아닌 곳에서 이미지 찾기 시도
            let imgEl = null;
            const cells = wrapper.querySelectorAll("td");
            if (cells.length > 1) {
                for (let i = 1; i < cells.length; i++) {
                    imgEl = cells[i].querySelector("img");
                    if (imgEl) {
                        const temp = resolveImageUrl(imgEl);
                        if (temp) break;
                        else imgEl = null;
                    }
                }
            }
            if (!imgEl) {
                imgEl = wrapper.querySelector("img");
            }

            const imageUrl = resolveImageUrl(imgEl);
            const image = await convertImageToBase64(imageUrl);

            const amount = bestPrice * val;
            if (bestName && bestPrice > 0) {
                items.push({
                    name: bestName,
                    price: bestPrice,
                    quantity: val,
                    amount: amount,
                    image: image
                });
            }
        } catch (e) {}
    }

    return items;
}
